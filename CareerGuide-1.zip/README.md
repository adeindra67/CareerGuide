# Career Guide - Navigating Your Path


“Career Guide" adalah sebuah aplikasi yang dirancang untuk membantu siswa dalam memilih karir yang sesuai dengan minat, keahlian, dan kepribadian mereka. 
Aplikasi ini dirancang untuk memberikan bimbingan yang lebih baik dan relevan bagi siswa dalam menemukan jalur karir yang tepat, dengan menyediakan informasi yang up-to-date dan fitur interaktif yang mendukung proses pengambilan keputusan mereka.

## Nama Anggota : 

- **MUHAMMAD ALI ZAFAR SIDIQ - (17223025)**
- **MOCHAMMAD RAFLY PRATAMA - (17221025)**
- **INDRA DWI SEPTIANTO - ( 17221034)**
- **RIO FERDINAN  - (17221000)**
- **M IRFAN - (17221007)**
